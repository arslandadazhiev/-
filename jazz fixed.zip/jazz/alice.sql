-- phpMyAdmin SQL Dump
-- version 4.9.5
-- https://www.phpmyadmin.net/
--
-- Хост: localhost:3306
-- Время создания: Дек 14 2023 г., 10:51
-- Версия сервера: 5.7.24
-- Версия PHP: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `alice`
--

-- --------------------------------------------------------

--
-- Структура таблицы `artist`
--

CREATE TABLE `artist` (
  `id` int(3) NOT NULL,
  `name` varchar(32) NOT NULL,
  `descr` varchar(255) NOT NULL,
  `photo` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `artist`
--

INSERT INTO `artist` (`id`, `name`, `descr`, `photo`) VALUES
(1, 'Miles Davis', 'Miles_Davis_descr', 'miles_davis.jpg'),
(2, 'Steve Lacy', 'Steve_Lacy_descr', 'Steve_Lacy.jpg'),
(3, 'Frank Sinatra', 'Frank_Sinatra_descr', 'Frank_Sinatra.jpg'),
(4, 'Michael Buble', 'Michael_Buble_descr', 'Michael_Buble.jpg'),
(5, 'Norah Jones', 'Norah_Jones_descr', 'Norah_Jones.jpg');

-- --------------------------------------------------------

--
-- Структура таблицы `links`
--

CREATE TABLE `links` (
  `id` int(3) NOT NULL,
  `artist_id` int(3) NOT NULL,
  `link` varchar(120) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `links`
--

INSERT INTO `links` (`id`, `artist_id`, `link`) VALUES
(1, 1, 'https://music.yandex.ru/artist/34?from=serp_autoplay'),
(2, 1, 'http://www.youtube.com/user/MilesDavisVEVO'),
(3, 2, 'http://www.tiktok.com/@steve.lacy'),
(4, 2, 'http://www.youtube.com/channel/UCRt1A0W4iZfvsOhAH1yft2Q'),
(5, 2, 'https://music.yandex.ru/artist/6092417?from=serp_autoplay'),
(6, 3, 'http://www.youtube.com/user/FrankSinatra'),
(7, 3, 'https://kinopoisk.ru/name/74573'),
(8, 3, 'https://music.yandex.ru/artist/3989?from=serp_autoplay'),
(9, 3, 'http://imdb.com/name/nm0000069'),
(10, 4, 'https://music.yandex.ru/artist/26158?from=serp_autoplay'),
(11, 4, 'http://www.youtube.com/channel/UCHqQruhGENdmWy_oeH1f8QA'),
(12, 4, 'http://www.tiktok.com/@michaelbuble'),
(13, 5, 'https://music.yandex.ru/artist/593?from=serp_autoplay'),
(14, 5, 'http://www.youtube.com/channel/UCBJtGODWGrM3fdQ0G5E9uAQ');

-- --------------------------------------------------------

--
-- Структура таблицы `songs`
--

CREATE TABLE `songs` (
  `id` int(3) NOT NULL,
  `artist_id` int(3) NOT NULL,
  `trackname` varchar(50) NOT NULL,
  `cover` varchar(32) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `songs`
--

INSERT INTO `songs` (`id`, `artist_id`, `trackname`, `cover`) VALUES
(2, 1, 'Miles Davis-Blue in Green', 'Blue_in_green_cover');

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `artist`
--
ALTER TABLE `artist`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id` (`id`);

--
-- Индексы таблицы `links`
--
ALTER TABLE `links`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `songs`
--
ALTER TABLE `songs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `artist_id` (`artist_id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `artist`
--
ALTER TABLE `artist`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT для таблицы `links`
--
ALTER TABLE `links`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `songs`
--
ALTER TABLE `songs`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
