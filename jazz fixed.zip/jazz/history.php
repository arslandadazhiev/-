<?php 
include("website.php");
$sc=new SiteClass;
?> 
<!doctype html>
<html lang="en">
<head>
<?php $sc->print_SEO("Открывайте для себя и делитесь постоянно расширяющейся подборкой музыки от начинающих и крупных исполнителей по всему миру. ","record, sounds, share, sound, audio, tracks, music","История джаза"); ?>

<meta http-equiv="Content-Type" content="text/html;charset=UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="language" content="en" />
<meta name="robots" content="all" />
<link href="css/bootstrap.min.css" rel="stylesheet">
<script src="js/jquery-3.7.1.js"></script>
 
    <style>
       .bd-placeholder-img {
        font-size: 1.125rem;
        text-anchor: middle;
        -webkit-user-select: none;
        -moz-user-select: none;
        user-select: none;
      }

      @media (min-width: 768px) {
        .bd-placeholder-img-lg {
          font-size: 3.5rem;
        }
      }

      .b-example-divider {
        width: 100%;
        height: 3rem;
        background-color: rgba(0, 0, 0, .1);
        border: solid rgba(0, 0, 0, .15);
        border-width: 1px 0;
        box-shadow: inset 0 .5em 1.5em rgba(0, 0, 0, .1), inset 0 .125em .5em rgba(0, 0, 0, .15);
      }

      .b-example-vr {
        flex-shrink: 0;
        width: 1.5rem;
        height: 100vh;
      }

      .bi {
        vertical-align: -.125em;
        fill: currentColor;
      }

      .nav-scroller {
        position: relative;
        z-index: 2;
        height: 2.75rem;
        overflow-y: hidden;
      }

      .nav-scroller .nav {
        display: flex;
        flex-wrap: nowrap;
        padding-bottom: 1rem;
        margin-top: -1px;
        overflow-x: auto;
        text-align: center;
        white-space: nowrap;
        -webkit-overflow-scrolling: touch;
      }

      .btn-bd-primary {
        --bd-violet-bg: #712cf9;
        --bd-violet-rgb: 112.520718, 44.062154, 249.437846;

        --bs-btn-font-weight: 600;
        --bs-btn-color: var(--bs-white);
        --bs-btn-bg: var(--bd-violet-bg);
        --bs-btn-border-color: var(--bd-violet-bg);
        --bs-btn-hover-color: var(--bs-white);
        --bs-btn-hover-bg: #6528e0;
        --bs-btn-hover-border-color: #6528e0;
        --bs-btn-focus-shadow-rgb: var(--bd-violet-rgb);
        --bs-btn-active-color: var(--bs-btn-hover-color);
        --bs-btn-active-bg: #5a23c8;
        --bs-btn-active-border-color: #5a23c8;
      }

      .bd-mode-toggle {
        z-index: 1500;
      }

      .bd-mode-toggle .dropdown-menu .active .bi {
        display: block !important;
      }
    </style>

    
    <!-- Custom styles for this template -->
     
  </head>
  <body>
    <svg xmlns="http://www.w3.org/2000/svg" class="d-none">
      <symbol id="check2" viewBox="0 0 16 16">
        <path d="M13.854 3.646a.5.5 0 0 1 0 .708l-7 7a.5.5 0 0 1-.708 0l-3.5-3.5a.5.5 0 1 1 .708-.708L6.5 10.293l6.646-6.647a.5.5 0 0 1 .708 0z"/>
      </symbol>
      <symbol id="circle-half" viewBox="0 0 16 16">
        <path d="M8 15A7 7 0 1 0 8 1v14zm0 1A8 8 0 1 1 8 0a8 8 0 0 1 0 16z"/>
      </symbol>
      <symbol id="moon-stars-fill" viewBox="0 0 16 16">
        <path d="M6 .278a.768.768 0 0 1 .08.858 7.208 7.208 0 0 0-.878 3.46c0 4.021 3.278 7.277 7.318 7.277.527 0 1.04-.055 1.533-.16a.787.787 0 0 1 .81.316.733.733 0 0 1-.031.893A8.349 8.349 0 0 1 8.344 16C3.734 16 0 12.286 0 7.71 0 4.266 2.114 1.312 5.124.06A.752.752 0 0 1 6 .278z"/>
        <path d="M10.794 3.148a.217.217 0 0 1 .412 0l.387 1.162c.173.518.579.924 1.097 1.097l1.162.387a.217.217 0 0 1 0 .412l-1.162.387a1.734 1.734 0 0 0-1.097 1.097l-.387 1.162a.217.217 0 0 1-.412 0l-.387-1.162A1.734 1.734 0 0 0 9.31 6.593l-1.162-.387a.217.217 0 0 1 0-.412l1.162-.387a1.734 1.734 0 0 0 1.097-1.097l.387-1.162zM13.863.099a.145.145 0 0 1 .274 0l.258.774c.115.346.386.617.732.732l.774.258a.145.145 0 0 1 0 .274l-.774.258a1.156 1.156 0 0 0-.732.732l-.258.774a.145.145 0 0 1-.274 0l-.258-.774a1.156 1.156 0 0 0-.732-.732l-.774-.258a.145.145 0 0 1 0-.274l.774-.258c.346-.115.617-.386.732-.732L13.863.1z"/>
      </symbol>
      <symbol id="sun-fill" viewBox="0 0 16 16">
        <path d="M8 12a4 4 0 1 0 0-8 4 4 0 0 0 0 8zM8 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 0zm0 13a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2A.5.5 0 0 1 8 13zm8-5a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2a.5.5 0 0 1 .5.5zM3 8a.5.5 0 0 1-.5.5h-2a.5.5 0 0 1 0-1h2A.5.5 0 0 1 3 8zm10.657-5.657a.5.5 0 0 1 0 .707l-1.414 1.415a.5.5 0 1 1-.707-.708l1.414-1.414a.5.5 0 0 1 .707 0zm-9.193 9.193a.5.5 0 0 1 0 .707L3.05 13.657a.5.5 0 0 1-.707-.707l1.414-1.414a.5.5 0 0 1 .707 0zm9.193 2.121a.5.5 0 0 1-.707 0l-1.414-1.414a.5.5 0 0 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .707zM4.464 4.465a.5.5 0 0 1-.707 0L2.343 3.05a.5.5 0 1 1 .707-.707l1.414 1.414a.5.5 0 0 1 0 .708z"/>
      </symbol>
    </svg>

       
<svg xmlns="http://www.w3.org/2000/svg" class="d-none">
  <symbol id="aperture" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2" viewBox="0 0 24 24">
    <circle cx="12" cy="12" r="10"/>
    <path d="M14.31 8l5.74 9.94M9.69 8h11.48M7.38 12l5.74-9.94M9.69 16L3.95 6.06M14.31 16H2.83m13.79-4l-5.74 9.94"/>
  </symbol>
  <symbol id="cart" viewBox="0 0 16 16">
    <path d="M0 1.5A.5.5 0 0 1 .5 1H2a.5.5 0 0 1 .485.379L2.89 3H14.5a.5.5 0 0 1 .49.598l-1 5a.5.5 0 0 1-.465.401l-9.397.472L4.415 11H13a.5.5 0 0 1 0 1H4a.5.5 0 0 1-.491-.408L2.01 3.607 1.61 2H.5a.5.5 0 0 1-.5-.5zM3.102 4l.84 4.479 9.144-.459L13.89 4H3.102zM5 12a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm7 0a2 2 0 1 0 0 4 2 2 0 0 0 0-4zm-7 1a1 1 0 1 1 0 2 1 1 0 0 1 0-2zm7 0a1 1 0 1 1 0 2 1 1 0 0 1 0-2z"/>
  </symbol>
  <symbol id="chevron-right" viewBox="0 0 16 16">
    <path fill-rule="evenodd" d="M4.646 1.646a.5.5 0 0 1 .708 0l6 6a.5.5 0 0 1 0 .708l-6 6a.5.5 0 0 1-.708-.708L10.293 8 4.646 2.354a.5.5 0 0 1 0-.708z"/>
  </symbol>
</svg>

<?php $sc->print_nav(); ?>

<main>
 

<div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-1 flex-grow-1 col-text">
                <div class="text-wrap">
                    <h2 class="mbr-section-title mbr-fonts-style mb-0 align-center display-1">Джаз?</h2>
                    <p class="mbr-text mbr-fonts-style mb-0 align-center display-7">
                    Джаз (англ. Jazz) — форма музыкального искусства, возникшая в начале XX века в США в результате синтеза африканской и европейской культур и получившая впоследствии повсеместное распространение.
                    Джаз - потрясающая музыка, живая, непрестанно развивающаяcя, вобравшая ритмический гений Африки, сокровища тысячелетнего искусства игры на барабанах, ритуальных, обрядовых песнопений. Добавьте хоровое и сольное пение баптистских, протестантских церквей - противоположные вещи слились воедино, подарив миру удивительное искусство!
                    История джаза необычна, динамична, наполнена удивительными событиями, которые повлияли на мировой музыкальный процесс.
                    </p>
                    
                </div>
            </div>
            <div class="col-12 col-lg-auto col-img">
                <div class="img-wrap">
                    <div class="img-box">
                        <img src="images/history1.jpg" alt="Mobirise Website Builder">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="features1 adaptm5 cid-tqnElwBPRR" id="afeatures1-c">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-1 flex-grow-1 col-text">
                <div class="text-wrap">
                    <h2 class="mbr-section-title mbr-fonts-style mb-0 align-center display-1">Что такое Джаз?</h2>
                    <p class="mbr-text mbr-fonts-style mb-0 align-center display-7">                    
                        Характерные черты:

                        <ul>
                        <li>полиритмия, основанная на синкопированных ритмах,</li>
                        <li>бит - регулярная пульсация,</li>
                        <li>свинг - отклонение от бита, комплекс приёмов исполнения ритмической фактуры,</li>
                        <li>импровизационность</li>
                        <li>красочный гармонический и тембровый ряд.</li>
                        </ul>
                        красочный гармонический и тембровый ряд.
                        Это направление музыки возникло в начале двадцатого века в результате синтеза африканской и европейской культур как искусство, основанное на импровизации в сочетании с заранее продуманной, но не обязательно записанной формой композиции. Импровизировать могут одновременно несколько исполнителей, даже если в ансамбле явно слышен солирующий голос. Законченный художественный образ произведения зависит от взаимодействия членов ансамбля между собой и с аудиторией.

                        Дальнейшее развитие нового музыкального направления происходило за счёт освоения композиторами новых ритмических, гармонических моделей.

                        Кроме особой выразительной роли ритма были унаследованы другие черты африканской музыки - трактовка всех инструментов как ударных, ритмических; преобладание разговорных интонаций в пении, подражание разговорной речи при игре на гитаре, фортепиано, ударных инструментах.
                            </p>
               
                </div>
            </div>
            <div class="col-12 col-lg-auto col-img">
                <div class="img-wrap">
                    <div class="img-box">
                        <img src="images/history2.jpg" alt="Mobirise Website Builder">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-1 flex-grow-1 col-text">
                <div class="text-wrap">
                    <h2 class="mbr-section-title mbr-fonts-style mb-0 align-center display-1">30-х</h2>
                    <p class="mbr-text mbr-fonts-style mb-0 align-center display-7">
                    
                
                    Американский джаз 30-х годов коммерциализировался. Поэтому в среде любителей и знатоков истории происхождения джаза возникло движение за возрождение более ранних, подлинных стилей. Решающую роль сыграли небольшие негритянские ансамбли 40-х годов, отбросившие все рассчитанное на внешний эффект: эстрадность, танцевальность, песенность. Тема проигрывалась в унисон и почти не звучала в оригинальном виде, аккомпанемент уже не требовал танцевальной регулярности.

                Этот стиль, открывающий современную эпоху, получил название "боп" или "бибоп". Эксперименты талантливых американских музыкантов и исполнителей джаза— Чарли Паркера, Диззи Гиллеспи, Телониуса Монка и других — фактически положили начало развитию самостоятельного вида искусства, лишь внешне связанного с эстрадно-танцевальным жанром.
               
                </p>
                     
                </div>
            </div>
            <div class="col-12 col-lg-auto col-img">
                <div class="img-wrap">
                    <div class="img-box">
                        <img src="images/history4.jpg" alt="Mobirise Website Builder">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section data-bs-version="5.1" class="features1 adaptm5 cid-tqnElwBPRR" id="afeatures1-c">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-1 flex-grow-1 col-text">
                <div class="text-wrap">
                    <h2 class="mbr-section-title mbr-fonts-style mb-0 align-center display-1">40-60-х</h2>
                    <p class="mbr-text mbr-fonts-style mb-0 align-center display-7"> 
                         С конца 40-х до середины 60-х годов развитие происходило в двух направлениях. Первое включало стили "cool" - "прохладный", и "west coast" - “западное побережье”. Для них характерно широкое использование опыта классической и современной серьезной музыки - развитые концертные формы, полифония. Второе направление включало стили "хардбоп" - "горячий", "энергичный" и близкий ему “soul-jazz" (в переводе с английского "soul" — "душа"), сочетавшие принципы старого бибопа с традициями негритянского фольклора, темпераментные ритмы и интонации спиричуэлов.

                                    Оба этих направления имеют много общего в стремлении освободиться от деления импровизации на отдельные квадраты, а также свинговать вальсовые и более сложные размеры.

                                    Были предприняты попытки создания произведений крупной формы - симфоджаз. Например "Рапсодия в блюзовых тонах" Дж. Гершвина, ряд сочинений И.Ф. Стравинского. С середины 50-х гг. эксперименты по соединению принципов джаза и современной музыки вновь получили распространение, уже под названием "третье течение", также и у русских исполнителей ("Концерт для оркестра" А.Я. Эшпая, произведения М.М. Кажлаева, 2-й концерт для фортепьяно с оркестром Р.К. Щедрина, 1-я симфония А.Г. Шнитке). Вообще, история появления джаза богата на эксперименты, тесно переплетается с развитием классической музыки, ее новаторских направлений.
                                    </p>
                     
                </div>
            </div>
            <div class="col-12 col-lg-auto col-img">
                <div class="img-wrap">
                    <div class="img-box">
                        <img src="images/history5.jpg" alt="Mobirise Website Builder">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
 

<section data-bs-version="5.1" class="features1 adaptm5 cid-tqnElwBPRR" id="afeatures1-c">
    <div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-1 flex-grow-1 col-text">
                <div class="text-wrap">
                    <h2 class="mbr-section-title mbr-fonts-style mb-0 align-center display-1">60-70-ые</h2>
                    <p class="mbr-text mbr-fonts-style mb-0 align-center display-7">
                    С начала 60-х гг. начинаются активные эксперименты со спонтанной импровизацией, не ограниченной даже конкретной музыкальной темой - Freejazz. Однако еще большее значение получает ладовый принцип: каждый раз заново выбирается ряд звуков — лад, а не четко различимые квадраты. В поисках таких ладов музыканты обращается к культурам Азии, Африки, Европы и др. В 70-е гг. приходят электроинструменты и ритмы молодежной рок-музыки, основанной на более мелком, чем ранее, дроблении такта. Этот стиль получает сначала название "fusion", т.е. "сплав".

                    Говоря кратко, история джаза - это повествование о поиске, единении, смелых экспериментах, горячей любви к музыке.                    </p>
                    
                </div>
            </div>
            <div class="col-12 col-lg-auto col-img">
                <div class="img-wrap">
                    <div class="img-box">
                        <img src="images/history6.jpg" style="width: 500px;" alt="Mobirise Website Builder">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<div class="container">
        <div class="row align-items-center">
            <div class="col-12 col-lg-1 flex-grow-1 col-text">
                <div class="text-wrap">
                    <h2 class="mbr-section-title mbr-fonts-style mb-0 align-center display-1">Джаз в современном мире</h2>
                    <p class="mbr-text mbr-fonts-style mb-0 align-center display-7">
                    Сегодняшний мир музыки разнообразен, динамично развивается, зарождаются новые стили. Для того, чтобы свободно в нем ориентироваться, понимать происходящие процессы, необходимо знание хотя бы краткой истории джаза! Сегодня мы наблюдаем смешение всё большего числа всемирных культур, постоянно приближающего нас к тому, что в сущности уже становится "всемирной музыкой" (world music). Сегодняшний джаз вбирает в себя звуки и традиции практически из любого уголка земного шара. В том числе переосмысливается и африканская культура, с которой все начиналось. Европейский экспериментализм с классическим подтекстом продолжает влиять на музыку молодых пионеров, таких, как Кен Вандермарк, авангардист-саксофонист, известный по работе с такими известными современниками, как саксофонисты Мэтс Густафссон, Эван Паркер и Питер Броцманн. К другим молодым музыкантам более традиционной ориентации, которые продолжают поиски своего собственного тождества, относятся пианисты Джекки Террассон, Бенни Грин и Брэйд Мелдоа, саксофонисты Джошуа Редман и Дэвид Санчес и барабанщики Джефф Уоттс и Билли Стюарт. Старая традиция звучания продолжается и активно поддерживается такими художниками, как трубач Уинтон Марсалис, который работает с целой командой помощников, играет в собственных маленьких группах и возглавляет Оркестр Центра Линкольна. Под его покровительством выросли в больших мастеров пианисты Маркус Робертс и Эрик Рид, саксофонист Уэс "Warmdaddy" Эндерсон, трубач Маркус Принтуп и вибрафонист Стефан Харрис.

Басист Дейв Холланд также является прекрасным открывателем молодых талантов. Среди многих его открытий саксофонисты Стив Коулмен, Стив Уилсон, вибрафонист Стив Нельсон и барабанщик Билли Килсон.

К числу других великих наставников молодых талантов относятся легендарный пианист Чик Кориа, и ныне покойные барабанщик Элвин Джонс и певица Бетти Картер. Потенциальные возможности дальнейшего развития этой музыки в настоящее время велики и разнообразны. Например, саксофонист Крис Поттер под собственным именем выпускает мэйнстримовый релиз и одновременно участвует в записи с другим великим авнгардистом барабанщиком Полом Мотианом.

Нам еще предстоит насладится сотнями прекрасных концертов и смелых экспериментов, стать свидетелями зарождения новых направлений и стилей - эта повесть еще не дописана до конца!
                    </p>
                     
                </div>
            </div>
            <div class="col-12 col-lg-auto col-img">
                <div class="img-wrap">
                    <div class="img-box">
                        <img src="images/history7.jpg" style="width: 600px;" alt="Mobirise Website Builder">
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>


</main>

<?php $sc->print_footer(); ?>
<script>

</script>
</body>
</html>