var mySong=document.getElementById("mySong");
var icon=document.getElementById("icon");

icon.onclick=function(){
    if(mySong.paused){
        mySong.play();
        icon.src="icons/play.svg"
    }else{
        mySong.pause();
        icon.src="icons/pause.svg"
    }
}